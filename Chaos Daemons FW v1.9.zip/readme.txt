Place this file in C:\Users\YourName\BattleScribe\data\Warhammer 40,000 9th Edition. Appears next to Daemons in BattleScribe.
Contains updates for every Forge World unit, meaning:
Aetaos'rau'keres
An'ggrath the Unbound
Cor'bax Utterblight
Giant Chaos Spawn
Furies
Ka'bandha
Mamon Transfigured
Plague Hulk of Nurgle
Plague Toads
Pox Riders
Samus
Scabeiathrax the Bloated
Spined Chaos Beast
Uraka the Warfiend
Zarakynel

If you discover a bug, inconsistency or etc., click on the Issues tab, then New Issue. Describe your problem clearly and concisely and I'll fix it as soon as. You could also give me some criticism or give any ideas for this stuff.
You could also send me an email to an account I made at mong94bdc@hotmail.com.
Or you can send me a message to a discord account I also made at mong#2655. Just make sure you aren't a creep.